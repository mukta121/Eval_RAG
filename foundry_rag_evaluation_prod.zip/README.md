# Production Microsoft Foundry RAG Evaluation

This package replaces the screenshot implementation with a cleaner production design for **precomputed RAG responses**.

## Why this version is safer

The earlier implementation had a good foundation, but mixed deterministic retrieval logic, Foundry cloud metrics, output parsing, reporting, and pass/fail policy in one large module. It also converted missing cloud outputs into report rows that could look like `0/0`, making an evaluator execution/parsing problem look like a model-quality failure.

This version keeps four states separate:

- `completed`
- `missing`
- `not_applicable`
- actual evaluator `pass` / `fail`

A missing evaluator output is **never** silently converted to score zero.

## Recommended metric design

For a normal RAG QA test set:

**Deterministic local retrieval**
- context recall
- context precision
- hit@k
- MRR

**Foundry RAG quality**
- retrieval
- groundedness
- relevance
- response completeness

**Foundry safety**
- hate/unfairness
- ungrounded attributes

`indirect_attack` / XPIA is opt-in. Use it on prompt-injection test cases rather than treating every ordinary business question as an XPIA test.

Task Adherence and Quality Grader were intentionally removed from the default RAG run:
- Task Adherence is principally an agent-behavior evaluator and is preview.
- Quality Grader overlaps with several granular quality dimensions. Running it alongside groundedness + relevance + completeness increases judge cost and can double-count the same quality signal.

You can add separate agent-evaluation suites later for tool use and task adherence.

## Install

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
az login
```

Copy `.env.example` to `.env` and fill in the project endpoint and judge deployment.

## Run

```bash
python foundry_rag_evaluator.py ^
  --ground-truth ground_truth.json ^
  --responses response_generator.json ^
  --output evaluation_foundry_result.json ^
  --excel-output evaluation_foundry_result.xlsx ^
  --raw-output foundry_raw_output.json
```

To include XPIA:

```bash
python foundry_rag_evaluator.py ^
  --ground-truth ground_truth.json ^
  --responses response_generator.json ^
  --metrics retrieval groundedness relevance response_completeness hate_unfairness ungrounded_attributes indirect_attack
```

## Ground truth example

```json
[
  {
    "query": "When is prior authorization required?",
    "ground_truth_answer": "Prior authorization is required before...",
    "relevant_contexts": [
      {
        "chunk_id": "DOC1_table_001_part_01",
        "content": "..."
      }
    ]
  }
]
```

## Response example

```json
[
  {
    "query": "When is prior authorization required?",
    "generated_answer": "Prior authorization is required before...",
    "retrieved_contexts": [
      {
        "chunk_id": "DOC1_table_001_part_01",
        "content": "...",
        "score": 0.93
      }
    ]
  }
]
```

## Production behavior

The evaluation resource is **kept by default**, because the Foundry report is useful for audit, comparison, debugging, and release evidence. Use `--delete-evaluation` only for disposable development runs.

Use `--fail-on-missing-cloud-metric` in CI/CD so a cloud-evaluator/parser failure cannot quietly pass your release gate.

The hard gate is deliberately narrower than “all metrics must pass”. It currently requires:
- context recall
- groundedness
- relevance
- response completeness

Safety remains visible independently. Adapt hard gates to your release policy rather than using a fixed “10/10” rule.
